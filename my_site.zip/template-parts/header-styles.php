<!-- header styles -->

<?php
   $localFonts = apply_filters('get_local_fonts', '');
?>
<?php if ($localFonts) : ?> 
   <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/<?php echo $localFonts; ?>" media="screen" type="text/css" />
<?php else : ?>
   <?php endif; ?>
<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
<style> .u-header {
  background-image: none;
}
.u-header .u-sheet-1 {
  min-height: 137px;
}
.u-header .u-menu-1 {
  margin: 79px 0 0 auto;
}
.u-header .u-nav-1 {
  font-size: 1rem;
  letter-spacing: 0px;
}
.u-block-6c8a-19 {
  box-shadow: 2px 2px 8px 0 rgba(128,128,128,1);
}
.u-header .u-nav-2 {
  font-size: 1.25rem;
}
.u-block-6c8a-17 {
  box-shadow: 2px 2px 8px 0 rgba(128,128,128,1);
}
.u-header .u-image-1 {
  width: 1080px;
  height: 1080px;
  margin: 30px 0 60px auto;
}
.u-header .u-logo-image-1 {
  width: 100%;
  height: 100%;
}
@media (max-width: 1199px) {
  .u-header .u-menu-1 {
    width: auto;
  }
  .u-header .u-image-1 {
    width: 940px;
    height: 940px;
  }
}
@media (max-width: 991px) {
  .u-header .u-image-1 {
    width: 720px;
    height: 720px;
  }
}
@media (max-width: 767px) {
  .u-header .u-image-1 {
    width: 540px;
    height: 540px;
  }
}
@media (max-width: 575px) {
  .u-header .u-image-1 {
    width: 340px;
    height: 340px;
  }
}</style>
